const express = require("express");
const path = require("path");
const router = express.Router();

const { getTarget } = require("../services/targetService");
const { runRecon } = require("../../tools/reconOrchestrator");

const {
  generateMarkdownReport,
  generateJsonReport
} = require("../../tools/reportGenerator");

const REPORT_DIR = path.resolve(__dirname, "../../reports");

router.get("/", async (req, res) => {
  try {
    const hostname = String(req.query.host || "")
      .toLowerCase()
      .trim();

    const format = String(req.query.format || "markdown")
      .toLowerCase()
      .trim();

    const target = getTarget(hostname);

    if (!target || !target.authorized) {
      return res.status(403).json({
        success: false,
        error: "Target is not in the authorized scope"
      });
    }

    if (!["markdown", "json"].includes(format)) {
      return res.status(400).json({
        success: false,
        error: "format must be markdown or json"
      });
    }

    const recon = await runRecon(target.url);

    const report = format === "json"
      ? generateJsonReport(recon)
      : generateMarkdownReport(recon);

    res.json({
      success: true,
      report: {
        filename: report.filename,
        format: report.format,
        downloadUrl:
          `/api/reports/download/${encodeURIComponent(report.filename)}`
      }
    });

  } catch (error) {
    res.status(502).json({
      success: false,
      error: error.message
    });
  }
});


router.get("/download/:filename", (req, res) => {
  try {
    const filename = path.basename(req.params.filename);

    if (!/^[a-z0-9._-]+\.(md|json)$/i.test(filename)) {
      return res.status(400).json({
        success: false,
        error: "Invalid report filename"
      });
    }

    const filePath = path.resolve(REPORT_DIR, filename);

    if (!filePath.startsWith(REPORT_DIR + path.sep)) {
      return res.status(400).json({
        success: false,
        error: "Invalid report path"
      });
    }

    res.download(filePath, filename, error => {
      if (error && !res.headersSent) {
        res.status(404).json({
          success: false,
          error: "Report not found"
        });
      }
    });

  } catch (error) {
    res.status(400).json({
      success: false,
      error: error.message
    });
  }
});


module.exports = router;
