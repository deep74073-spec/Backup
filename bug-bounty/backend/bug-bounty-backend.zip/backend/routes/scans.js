const express = require("express");
const router = express.Router();

const { listScans } = require("../services/scanService");

router.get("/", (req, res) => {
  res.json({
    success: true,
    scans: listScans()
  });
});

module.exports = router;
