const express = require("express");
const router = express.Router();

const { getTarget } = require("../services/targetService");
const { runRecon } = require("../../tools/reconOrchestrator");
const { addScan } = require("../services/scanService");

router.get("/", async (req, res) => {
  try {
    const hostname = String(req.query.host || "")
      .toLowerCase()
      .trim();

    const target = getTarget(hostname);

    if (!target || !target.authorized) {
      return res.status(403).json({
        success: false,
        error: "Target is not in the authorized scope"
      });
    }

    const result = await runRecon(target.url);

    const modules = Object.entries(result.results || {}).map(
      ([name, item]) => ({
        name,
        success: Boolean(item.success)
      })
    );

    const scan = addScan({
      target: target.hostname,
      completedAt: result.completedAt,
      modules
    });

    res.json({
      success: true,
      result,
      scan
    });

  } catch (error) {
    res.status(502).json({
      success: false,
      error: error.message
    });
  }
});

module.exports = router;
