const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "../../data");
const SCANS_FILE = path.join(DATA_DIR, "scans.json");

function ensureStorage() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (!fs.existsSync(SCANS_FILE)) {
    fs.writeFileSync(SCANS_FILE, "[]", "utf8");
  }
}

function loadScans() {
  ensureStorage();

  try {
    const data = fs.readFileSync(SCANS_FILE, "utf8");
    const scans = JSON.parse(data);

    return Array.isArray(scans) ? scans : [];
  } catch {
    return [];
  }
}

function saveScans(scans) {
  ensureStorage();

  fs.writeFileSync(
    SCANS_FILE,
    JSON.stringify(scans, null, 2),
    "utf8"
  );
}

const scans = loadScans();

function addScan({
  target,
  completedAt,
  modules
}) {
  const scan = {
    id: `S-${String(scans.length + 1).padStart(4, "0")}`,
    target,
    completedAt,
    modules,
    createdAt: new Date().toISOString()
  };

  scans.push(scan);
  saveScans(scans);

  return scan;
}

function listScans() {
  return [...scans].reverse();
}

module.exports = {
  addScan,
  listScans
};
