package com.bugbounty.tool

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import com.bugbounty.tool.ui.theme.BugBountyToolkitTheme
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.net.ssl.HttpsURLConnection

private const val PREFS = "bugbounty_native"
private const val TARGETS = "targets"
private const val SCANS = "scans"
private const val FINDINGS = "findings"

data class Target(
    val url: String,
    val hostname: String
)

data class Scan(
    val target: String,
    val time: String,
    val summary: String
)

data class Finding(
    val id: String,
    val target: String,
    val title: String,
    val severity: String,
    val evidence: String
)

private fun now(): String =
    SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

private fun prefs(context: Context) =
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

private fun loadTargets(context: Context): List<Target> {
    val a = JSONArray(prefs(context).getString(TARGETS, "[]"))
    return buildList {
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            add(Target(o.getString("url"), o.getString("hostname")))
        }
    }
}

private fun saveTargets(context: Context, list: List<Target>) {
    val a = JSONArray()
    list.forEach {
        a.put(
            JSONObject()
                .put("url", it.url)
                .put("hostname", it.hostname)
        )
    }
    prefs(context).edit().putString(TARGETS, a.toString()).apply()
}

private fun loadScans(context: Context): List<Scan> {
    val a = JSONArray(prefs(context).getString(SCANS, "[]"))
    return buildList {
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            add(
                Scan(
                    o.getString("target"),
                    o.getString("time"),
                    o.getString("summary")
                )
            )
        }
    }
}

private fun saveScan(context: Context, scan: Scan) {
    val list = loadScans(context).toMutableList()
    list.add(0, scan)

    val a = JSONArray()
    list.take(50).forEach {
        a.put(
            JSONObject()
                .put("target", it.target)
                .put("time", it.time)
                .put("summary", it.summary)
        )
    }

    prefs(context).edit().putString(SCANS, a.toString()).apply()
}

private fun loadFindings(context: Context): List<Finding> {
    val a = JSONArray(prefs(context).getString(FINDINGS, "[]"))
    return buildList {
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            add(
                Finding(
                    o.getString("id"),
                    o.getString("target"),
                    o.getString("title"),
                    o.getString("severity"),
                    o.getString("evidence")
                )
            )
        }
    }
}

private fun saveFinding(context: Context, finding: Finding) {
    val list = loadFindings(context).toMutableList()
    if (list.any { it.id == finding.id }) return

    list.add(0, finding)

    val a = JSONArray()
    list.forEach {
        a.put(
            JSONObject()
                .put("id", it.id)
                .put("target", it.target)
                .put("title", it.title)
                .put("severity", it.severity)
                .put("evidence", it.evidence)
        )
    }

    prefs(context).edit().putString(FINDINGS, a.toString()).apply()
}

private fun normalizeTarget(input: String): Target? {
    var value = input.trim()
    if (value.isEmpty()) return null

    if (!value.startsWith("http://") && !value.startsWith("https://")) {
        value = "https://$value"
    }

    val uri = runCatching { Uri.parse(value) }.getOrNull() ?: return null
    val host = uri.host ?: return null

    if (host.contains("..") || host.length > 253) return null

    return Target(
        url = value.trimEnd('/'),
        hostname = host.lowercase(Locale.US)
    )
}

private fun authorized(target: Target, context: Context): Boolean =
    loadTargets(context).any {
        it.hostname.equals(target.hostname, ignoreCase = true)
    }

private fun safeConnection(url: URL): HttpURLConnection {
    return (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 10000
        readTimeout = 15000
        instanceFollowRedirects = false
        useCaches = false
        setRequestProperty("User-Agent", "BugBountyToolkit/1.0")
    }
}

private fun readBody(connection: HttpURLConnection): String {
    return runCatching {
        connection.inputStream.bufferedReader().use { it.readText() }
    }.getOrElse { "" }
        .take(20000)
}

private fun runNativeRecon(target: Target): String {
    val out = StringBuilder()

    out.appendLine("TARGET: ${target.url}")
    out.appendLine("HOST: ${target.hostname}")
    out.appendLine("TIME: ${now()}")
    out.appendLine()

    runCatching {
        val addresses = InetAddress.getAllByName(target.hostname)
        out.appendLine("DNS")
        addresses.forEach { out.appendLine("  ${it.hostAddress}") }
        out.appendLine()
    }.onFailure {
        out.appendLine("DNS: ERROR ${it.message}")
        out.appendLine()
    }

    val connection = runCatching {
        safeConnection(URL(target.url))
    }.getOrNull()

    if (connection == null) {
        out.appendLine("HTTP: CONNECTION FAILED")
        return out.toString()
    }

    try {
        val code = connection.responseCode
        out.appendLine("HTTP")
        out.appendLine("  Status: $code")
        out.appendLine("  Content-Type: ${connection.contentType ?: "none"}")
        out.appendLine("  Server: ${connection.getHeaderField("Server") ?: "not disclosed"}")
        out.appendLine("  Location: ${connection.getHeaderField("Location") ?: "none"}")
        out.appendLine()

        val securityHeaders = listOf(
            "Strict-Transport-Security",
            "Content-Security-Policy",
            "X-Content-Type-Options",
            "X-Frame-Options",
            "Referrer-Policy",
            "Permissions-Policy",
            "Cross-Origin-Opener-Policy",
            "Cross-Origin-Resource-Policy"
        )

        out.appendLine("SECURITY HEADERS")
        securityHeaders.forEach { name ->
            val value = connection.getHeaderField(name)
            out.appendLine("  $name: ${value ?: "MISSING"}")
        }
        out.appendLine()

        out.appendLine("CORS")
        out.appendLine(
            "  Access-Control-Allow-Origin: " +
                (connection.getHeaderField("Access-Control-Allow-Origin") ?: "MISSING")
        )
        out.appendLine(
            "  Access-Control-Allow-Credentials: " +
                (connection.getHeaderField("Access-Control-Allow-Credentials") ?: "MISSING")
        )
        out.appendLine()

        if (target.url.startsWith("https://")) {
            runCatching {
                val https = connection as? HttpsURLConnection
                out.appendLine("TLS")
                out.appendLine(
                    "  Connection: ${if (https != null) "HTTPS" else "unknown"}"
                )
            }
        }

        val body = readBody(connection)

        out.appendLine("BASIC TECHNOLOGY")
        val lower = body.lowercase(Locale.US)

        when {
            "wp-content" in lower || "wordpress" in lower ->
                out.appendLine("  Possible WordPress indicators")
            "__next_data__" in lower || "_next/static" in lower ->
                out.appendLine("  Possible Next.js indicators")
            "react" in lower ->
                out.appendLine("  Possible React indicators")
            else ->
                out.appendLine("  No obvious framework indicator found")
        }

        out.appendLine()
        out.appendLine("SECURITY.TXT")
        runCatching {
            val base = URL(target.url)
            val securityUrl = URL(
                base.protocol,
                base.host,
                base.port,
                "/.well-known/security.txt"
            )
            val c = safeConnection(securityUrl)
            val status = c.responseCode
            out.appendLine("  Status: $status")
            if (status in 200..299) {
                out.appendLine("  Present: YES")
            } else {
                out.appendLine("  Present: NO/NOT AVAILABLE")
            }
            c.disconnect()
        }.onFailure {
            out.appendLine("  Check failed: ${it.message}")
        }

        return out.toString()
    } finally {
        connection.disconnect()
    }
}

private fun nextFindingId(context: Context): String {
    val numbers = loadFindings(context)
        .mapNotNull { it.id.removePrefix("F-").toIntOrNull() }

    val next = (numbers.maxOrNull() ?: 0) + 1
    return "F-%04d".format(Locale.US, next)
}

private fun buildMarkdownReport(
    target: String,
    recon: String,
    findings: List<Finding>
): String {
    return buildString {
        appendLine("# BugBounty Toolkit Report")
        appendLine()
        appendLine("- Target: `$target`")
        appendLine("- Generated: `${now()}`")
        appendLine()
        appendLine("## Safe Recon")
        appendLine()
        appendLine("```text")
        appendLine(recon)
        appendLine("```")
        appendLine()
        appendLine("## Findings")
        appendLine()

        if (findings.isEmpty()) {
            appendLine("No local findings recorded.")
        } else {
            findings.forEach {
                appendLine("### ${it.id} — ${it.title}")
                appendLine("- Severity: ${it.severity}")
                appendLine("- Evidence: ${it.evidence}")
                appendLine()
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            BugBountyToolkitTheme {
                NativeApp()
            }
        }
    }
}

@Composable
private fun NativeApp() {
    var screen by remember { mutableStateOf("Dashboard") }
    var selectedTarget by remember { mutableStateOf<Target?>(null) }

    when (screen) {
        "Dashboard" -> Dashboard(
            selectedTarget = selectedTarget,
            onOpen = { screen = it }
        )

        "Targets" -> TargetsScreen(
            selectedTarget = selectedTarget,
            onSelect = { selectedTarget = it },
            onBack = { screen = "Dashboard" }
        )

        "Safe Recon" -> ReconScreen(
            target = selectedTarget,
            onBack = { screen = "Dashboard" },
            onSelectTarget = { selectedTarget = it }
        )

        "Scan History" -> ScansScreen(
            onBack = { screen = "Dashboard" }
        )

        "Findings" -> FindingsScreen(
            onBack = { screen = "Dashboard" }
        )

        "Reports" -> ReportsScreen(
            target = selectedTarget,
            onBack = { screen = "Dashboard" }
        )

        "API Analysis" -> ApiAnalysisScreen(
            target = selectedTarget,
            onBack = { screen = "Dashboard" }
        )
    }
}

@Composable
private fun Dashboard(
    selectedTarget: Target?,
    onOpen: (String) -> Unit
) {
    val bg = Color(0xFF0B0F14)
    val card = Color(0xFF151B23)
    val green = Color(0xFF22C55E)
    val text = Color(0xFFF1F5F9)
    val muted = Color(0xFF94A3B8)

    val tools = listOf(
        "Targets" to "Authorized targets",
        "Safe Recon" to "Safe GET/metadata checks",
        "Scan History" to "Previous local scans",
        "Findings" to "Local security findings",
        "Reports" to "Local Markdown report",
        "API Analysis" to "Safe GET response analysis"
    )

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        color = bg
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painter = painterResource(R.drawable.bug_bounty_logo),
                    contentDescription = "BugBounty Toolkit",
                    modifier = Modifier.size(58.dp)
                )

                Column(modifier = Modifier.padding(start = 12.dp)) {
                    Text(
                        "BugBounty Toolkit",
                        color = text,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Native • No backend required",
                        color = green,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = card),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(18.dp)) {
                    Text(
                        "Toolkit Status",
                        color = text,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "● Native engine ready",
                        color = green,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        selectedTarget?.let {
                            "Selected: ${it.hostname}"
                        } ?: "No target selected",
                        color = muted,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Text(
                "Security Tools",
                color = text,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(10.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 10.dp)
            ) {
                items(tools) { tool ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(78.dp)
                            .clickable { onOpen(tool.first) },
                        color = card,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    tool.first,
                                    color = text,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    tool.second,
                                    color = muted,
                                    fontSize = 12.sp
                                )
                            }

                            Text(
                                "OPEN →",
                                color = green,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Button(
                onClick = { onOpen("Safe Recon") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = green,
                    contentColor = Color.Black
                )
            ) {
                Text("RUN SAFE RECON", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ScreenFrame(
    title: String,
    onBack: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val bg = Color(0xFF0B0F14)
    val green = Color(0xFF22C55E)
    val text = Color(0xFFF1F5F9)

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        color = bg
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp)
        ) {
            Text(
                "← Back",
                color = green,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { onBack() }
            )

            Spacer(Modifier.height(14.dp))

            Text(
                title,
                color = text,
                fontSize = 27.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(14.dp))

            content()
        }
    }
}

@Composable
private fun TargetsScreen(
    selectedTarget: Target?,
    onSelect: (Target) -> Unit,
    onBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var input by remember { mutableStateOf("") }
    var targets by remember { mutableStateOf(loadTargets(context)) }
    var message by remember { mutableStateOf("") }

    ScreenFrame("Targets", onBack) {
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Target URL / hostname") },
            placeholder = { Text("https://example.com") },
            singleLine = true
        )

        Spacer(Modifier.height(10.dp))

        Button(
            onClick = {
                val target = normalizeTarget(input)

                if (target == null) {
                    message = "Invalid target."
                } else if (targets.any {
                        it.hostname.equals(target.hostname, true)
                    }) {
                    message = "Target already added."
                } else {
                    targets = targets + target
                    saveTargets(context, targets)
                    input = ""
                    message = "Authorized target saved."
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("ADD AUTHORIZED TARGET")
        }

        if (message.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(message, color = Color(0xFF22C55E))
        }

        Spacer(Modifier.height(16.dp))

        if (targets.isEmpty()) {
            Text(
                "No targets yet.",
                color = Color(0xFF94A3B8)
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(targets) { target ->
                    val selected = selectedTarget?.hostname == target.hostname

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(target) },
                        color = if (selected)
                            Color(0xFF193323)
                        else
                            Color(0xFF151B23),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(15.dp)) {
                            Text(
                                target.hostname,
                                color = Color(0xFFF1F5F9),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                target.url,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                            if (selected) {
                                Text(
                                    "SELECTED",
                                    color = Color(0xFF22C55E),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReconScreen(
    target: Target?,
    onBack: () -> Unit,
    onSelectTarget: (Target) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var result by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }
    var targets by remember { mutableStateOf(loadTargets(context)) }

    ScreenFrame("Safe Recon", onBack) {
        if (target == null) {
            Text(
                "Select an authorized target first.",
                color = Color(0xFFF1F5F9)
            )

            Spacer(Modifier.height(10.dp))

            targets.forEach { item ->
                OutlinedButton(
                    onClick = { onSelectTarget(item) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(item.hostname)
                }
                Spacer(Modifier.height(6.dp))
            }
        } else {
            Text(
                "Target: ${target.hostname}",
                color = Color(0xFF22C55E),
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(10.dp))

            Button(
                enabled = !running,
                onClick = {
                    running = true
                    result = "Running safe checks..."

                    Thread {
                        val output = runNativeRecon(target)

                        saveScan(
                            context,
                            Scan(
                                target.hostname,
                                now(),
                                "Native safe recon completed"
                            )
                        )

                        if (output.contains("MISSING")) {
                            saveFinding(
                                context,
                                Finding(
                                    nextFindingId(context),
                                    target.hostname,
                                    "Security-header review required",
                                    "informational",
                                    "One or more recommended response headers were missing. Review manually; missing headers alone are not proof of a vulnerability."
                                )
                            )
                        }

                        android.os.Handler(
                            android.os.Looper.getMainLooper()
                        ).post {
                            result = output
                            running = false
                        }
                    }.start()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (running) "RUNNING..." else "RUN SAFE RECON")
            }

            Spacer(Modifier.height(12.dp))

            if (result.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    color = Color(0xFF111827),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.padding(14.dp)
                    ) {
                        item {
                            Text(
                                result,
                                color = Color(0xFFE5E7EB),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScansScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var scans by remember { mutableStateOf(loadScans(context)) }

    ScreenFrame("Scan History", onBack) {
        Button(
            onClick = { scans = loadScans(context) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("REFRESH")
        }

        Spacer(Modifier.height(10.dp))

        if (scans.isEmpty()) {
            Text(
                "No scans yet.",
                color = Color(0xFF94A3B8)
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(scans) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF151B23),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                it.target,
                                color = Color(0xFFF1F5F9),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                it.time,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                            Text(
                                it.summary,
                                color = Color(0xFF22C55E),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FindingsScreen(onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var findings by remember { mutableStateOf(loadFindings(context)) }

    ScreenFrame("Findings", onBack) {
        Button(
            onClick = { findings = loadFindings(context) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("REFRESH")
        }

        Spacer(Modifier.height(10.dp))

        if (findings.isEmpty()) {
            Text(
                "No findings recorded.",
                color = Color(0xFF94A3B8)
            )
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(findings) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = Color(0xFF151B23),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                "${it.id} • ${it.title}",
                                color = Color(0xFFF1F5F9),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "${it.target} • ${it.severity}",
                                color = Color(0xFF22C55E),
                                fontSize = 12.sp
                            )
                            Spacer(Modifier.height(5.dp))
                            Text(
                                it.evidence,
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportsScreen(
    target: Target?,
    onBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var report by remember { mutableStateOf("") }

    ScreenFrame("Reports", onBack) {
        if (target == null) {
            Text(
                "Select an authorized target first.",
                color = Color(0xFFF1F5F9)
            )
        } else {
            Button(
                onClick = {
                    report = buildMarkdownReport(
                        target.hostname,
                        "Run Safe Recon first to create a fresh report.",
                        loadFindings(context).filter {
                            it.target == target.hostname
                        }
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("GENERATE MARKDOWN")
            }

            Spacer(Modifier.height(10.dp))

            if (report.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    color = Color(0xFF111827),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    LazyColumn(Modifier.padding(14.dp)) {
                        item {
                            Text(
                                report,
                                color = Color(0xFFE5E7EB),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ApiAnalysisScreen(
    target: Target?,
    onBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var endpoint by remember { mutableStateOf("/") }
    var result by remember { mutableStateOf("") }
    var running by remember { mutableStateOf(false) }

    ScreenFrame("API Analysis", onBack) {
        if (target == null) {
            Text(
                "Select an authorized target first.",
                color = Color(0xFFF1F5F9)
            )
        } else {
            Text(
                "Target: ${target.hostname}",
                color = Color(0xFF22C55E),
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(8.dp))

            OutlinedTextField(
                value = endpoint,
                onValueChange = {
                    endpoint = if (it.startsWith("/")) it else "/$it"
                },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("GET endpoint") },
                singleLine = true
            )

            Spacer(Modifier.height(8.dp))

            Button(
                enabled = !running,
                onClick = {
                    running = true
                    result = "Running safe GET..."

                    Thread {
                        val output = runCatching {
                            val base = URL(target.url)
                            val safePath =
                                endpoint.substringBefore('?')
                            val url = URL(
                                base.protocol,
                                base.host,
                                base.port,
                                safePath
                            )

                            val c = safeConnection(url)

                            try {
                                buildString {
                                    appendLine("URL: $url")
                                    appendLine("STATUS: ${c.responseCode}")
                                    appendLine(
                                        "CONTENT-TYPE: ${
                                            c.contentType ?: "none"
                                        }"
                                    )
                                    appendLine()
                                    appendLine("HEADERS")
                                    c.headerFields.forEach { (k, v) ->
                                        if (k != null) {
                                            appendLine(
                                                "$k: ${v.joinToString(", ")}"
                                            )
                                        }
                                    }
                                    appendLine()
                                    appendLine("BODY PREVIEW")
                                    appendLine(readBody(c))
                                }
                            } finally {
                                c.disconnect()
                            }
                        }.getOrElse {
                            "ERROR: ${it.message}"
                        }

                        android.os.Handler(
                            android.os.Looper.getMainLooper()
                        ).post {
                            result = output
                            running = false
                        }
                    }.start()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (running) "RUNNING..." else "RUN SAFE GET")
            }

            Spacer(Modifier.height(10.dp))

            if (result.isNotEmpty()) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    color = Color(0xFF111827),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    LazyColumn(Modifier.padding(14.dp)) {
                        item {
                            Text(
                                result,
                                color = Color(0xFFE5E7EB),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
