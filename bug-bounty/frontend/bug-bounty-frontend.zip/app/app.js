let selectedTarget = "";

async function api(url, options = {}) {
  const response = await fetch(url, options);

  let data;

  try {
    data = await response.json();
  } catch {
    throw new Error(`Server returned HTTP ${response.status}`);
  }

  if (!response.ok || data.success === false) {
    throw new Error(data.error || `HTTP ${response.status}`);
  }

  return data;
}



function formatValue(value) {
  if (value === null || value === undefined || value === "") {
    return "—";
  }

  if (Array.isArray(value)) {
    if (!value.length) return "—";

    return value.map(item => {
      if (typeof item === "object") {
        return JSON.stringify(item);
      }
      return String(item);
    }).join("<br>");
  }

  if (typeof value === "object") {
    return Object.entries(value)
      .map(([key, val]) =>
        `<div><strong>${escapeHtml(key)}:</strong> ${formatValue(val)}</div>`
      )
      .join("");
  }

  return escapeHtml(String(value));
}

function renderDetails(name, result) {
  if (!result || typeof result !== "object") {
    return "";
  }

  switch (name) {
    case "httpSecurity": {
      const headers = result.securityHeaders || {};

      return Object.entries(headers)
        .map(([header, present]) => `
          <div class="detail-row">
            <span>${escapeHtml(header)}</span>
            <span class="${present ? "ok" : "missing"}">
              ${present ? "Present" : "Missing"}
            </span>
          </div>
        `)
        .join("");
    }

    case "tls": {
      const cert = result.certificate || {};

      return `
        <div class="detail-row">
          <span>Protocol</span>
          <strong>${formatValue(result.protocol)}</strong>
        </div>

        <div class="detail-row">
          <span>Trusted</span>
          <strong>${result.authorized ? "Yes" : "No"}</strong>
        </div>

        <div class="detail-row">
          <span>Subject</span>
          <strong>${formatValue(cert.subject)}</strong>
        </div>

        <div class="detail-row">
          <span>Issuer</span>
          <strong>${formatValue(cert.issuer)}</strong>
        </div>

        <div class="detail-row">
          <span>Valid From</span>
          <strong>${formatValue(cert.validFrom)}</strong>
        </div>

        <div class="detail-row">
          <span>Valid To</span>
          <strong>${formatValue(cert.validTo)}</strong>
        </div>
      `;
    }

    case "dns":
      return Object.entries(result)
        .filter(([key]) => key !== "hostname")
        .map(([key, value]) => `
          <div class="detail-block">
            <strong>${escapeHtml(key)}</strong>
            <div>${formatValue(value)}</div>
          </div>
        `)
        .join("");

    case "cors":
      return `
        <div class="detail-row">
          <span>Allow-Origin</span>
          <strong>${formatValue(result.cors?.accessControlAllowOrigin)}</strong>
        </div>

        <div class="detail-row">
          <span>Allow-Credentials</span>
          <strong>${formatValue(result.cors?.accessControlAllowCredentials)}</strong>
        </div>

        <div class="detail-row">
          <span>Allow-Methods</span>
          <strong>${formatValue(result.cors?.accessControlAllowMethods)}</strong>
        </div>

        <div class="detail-row">
          <span>Allow-Headers</span>
          <strong>${formatValue(result.cors?.accessControlAllowHeaders)}</strong>
        </div>
      `;

    case "securityTxt":
      return `
        <div class="detail-row">
          <span>Status</span>
          <strong>${formatValue(result.status)}</strong>
        </div>

        <div class="detail-row">
          <span>Found</span>
          <strong>${result.found ? "Yes" : "No"}</strong>
        </div>

        <div class="detail-block">
          <strong>Contact</strong>
          <div>${formatValue(result.fields?.contact)}</div>
        </div>
      `;

    case "httpMetadata":
      return `
        <div class="detail-row">
          <span>Status</span>
          <strong>${formatValue(result.status)}</strong>
        </div>

        <div class="detail-row">
          <span>Response Time</span>
          <strong>${formatValue(result.responseTimeMs)} ms</strong>
        </div>

        <div class="detail-row">
          <span>Server</span>
          <strong>${formatValue(result.headers?.server)}</strong>
        </div>

        <div class="detail-row">
          <span>Content-Type</span>
          <strong>${formatValue(result.headers?.contentType)}</strong>
        </div>
      `;

    case "technology":
      return `
        <div class="detail-block">
          ${result.technologies?.length
            ? result.technologies.map(item => `
                <div class="tech-item">
                  <strong>${escapeHtml(item.name)}</strong>
                  <small>${escapeHtml(item.source)}</small>
                </div>
              `).join("")
            : "No technology indicators detected."}
        </div>
      `;

    case "apiAnalysis":
      return `
        <div class="detail-row">
          <span>Status</span>
          <strong>${formatValue(result.status)}</strong>
        </div>

        <div class="detail-row">
          <span>Content-Type</span>
          <strong>${formatValue(result.contentType)}</strong>
        </div>

        <div class="detail-row">
          <span>Response Size</span>
          <strong>${formatValue(result.responseSize)} bytes</strong>
        </div>

        <div class="detail-row">
          <span>JSON Response</span>
          <strong>${result.json ? "Yes" : "No"}</strong>
        </div>
      `;

    default:
      return `
        <pre class="mini-json">${escapeHtml(
          JSON.stringify(result, null, 2)
        )}</pre>
      `;
  }
}

function renderRecon(data) {
  const results = data?.result?.results || {};
  const container = document.getElementById("results");
  const summary = document.getElementById("scanSummary");

  const entries = Object.entries(results);

  const successful = entries.filter(([, item]) => item.success).length;
  const failed = entries.length - successful;

  summary.innerHTML = `
    <div class="summary-box">
      <strong>${entries.length}</strong>
      <span>Checks</span>
    </div>
    <div class="summary-box">
      <strong>${successful}</strong>
      <span>Success</span>
    </div>
    <div class="summary-box">
      <strong>${failed}</strong>
      <span>Errors</span>
    </div>
  `;

  container.innerHTML = entries.map(([name, item]) => {
    if (!item.success) {
      return `
        <div class="result-card">
          <h3>${escapeHtml(name)}</h3>
          <div class="result-error">● Error</div>
          <small>${escapeHtml(item.error || "Unknown error")}</small>
        </div>
      `;
    }

    return `
      <div class="result-card">
        <h3>${escapeHtml(name)}</h3>

        <div class="result-success">
          ● Completed
        </div>

        <div class="result-details">
          ${renderDetails(name, item.result)}
        </div>
      </div>
    `;
  }).join("");
}

function showOutput(data) {
  document.getElementById("output").textContent =
    JSON.stringify(data, null, 2);
}


async function loadOverview() {
  try {
    const [targets, scans, findings, health] = await Promise.all([
      api("/api/targets"),
      api("/api/scans"),
      api("/api/findings"),
      api("/api/health")
    ]);

    document.getElementById("targetCount").textContent =
      targets.targets.length;

    document.getElementById("scanCount").textContent =
      scans.scans.length;

    document.getElementById("findingCount").textContent =
      findings.findings.length;

    document.getElementById("apiStatus").textContent =
      health.status === "ok" ? "OK" : "ERROR";

  } catch (error) {
    document.getElementById("apiStatus").textContent = "ERROR";
  }
}

async function loadTargets() {
  try {
    const data = await api("/api/targets");

    const container = document.getElementById("targets");

    if (!data.targets.length) {
      container.innerHTML = "<p>No authorized targets.</p>";
      return;
    }

    container.innerHTML = data.targets.map(target => `
      <div class="target">
        <strong>${escapeHtml(target.hostname)}</strong>
        <br>
        <small>${escapeHtml(target.url)}</small>
        <br>
        <button onclick="selectTarget('${escapeJs(target.hostname)}')">
          Select
        </button>
      </div>
    `).join("");

  } catch (error) {
    document.getElementById("targets").textContent =
      `Error: ${error.message}`;
  }
}

async function addTarget() {
  const input = document.getElementById("target");
  const value = input.value.trim();

  if (!value) {
    alert("Enter a target first.");
    return;
  }

  try {
    const data = await api("/api/targets", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        target: value
      })
    });

    selectedTarget = data.target.hostname;
    input.value = "";

    showOutput(data);
    await loadTargets();

  } catch (error) {
    alert(error.message);
  }
}

function selectTarget(hostname) {
  selectedTarget = hostname;

  document.getElementById("selectedTarget").textContent =
    `Selected: ${hostname}`;

  document.getElementById("output").textContent =
    `Selected target: ${hostname}`;

  document.getElementById("status").textContent =
    "● Target selected";
}

function requireTarget() {
  if (!selectedTarget) {
    alert("Select an authorized target first.");
    return false;
  }

  return true;
}

async function runRecon() {
  if (!requireTarget()) return;

  document.getElementById("output").textContent =
    "Running safe recon...";

  try {
    const data = await api(
      `/api/recon?host=${encodeURIComponent(selectedTarget)}`
    );

    showOutput(data);
    renderRecon(data);
    document.getElementById("status").textContent = "● Scan complete";
    await loadFindings();

  } catch (error) {
    document.getElementById("output").textContent =
      `Recon error: ${error.message}`;
  }
}

async function generateReport(format) {
  if (!requireTarget()) return;

  document.getElementById("output").textContent =
    `Generating ${format} report...`;

  try {
    const data = await api(
      `/api/reports?host=${encodeURIComponent(selectedTarget)}&format=${encodeURIComponent(format)}`
    );

    showOutput(data);

    if (data.report?.downloadUrl) {
      const link = document.createElement("a");
      link.href = data.report.downloadUrl;
      link.textContent = `Open ${data.report.filename}`;
      link.target = "_blank";
      link.className = "report-link";

      const output = document.getElementById("output");
      output.insertAdjacentElement("afterend", link);
    }

  } catch (error) {
    document.getElementById("output").textContent =
      `Report error: ${error.message}`;
  }
}


async function loadScans() {
  try {
    const data = await api("/api/scans");

    const container = document.getElementById("scans");

    if (!data.scans.length) {
      container.innerHTML =
        '<div class="empty">No scans yet.</div>';
      return;
    }

    container.innerHTML = data.scans.map(scan => {
      const modules = scan.modules || [];
      const successful = modules.filter(
        module => module.success
      ).length;

      return `
        <div class="scan-item">
          <div class="scan-header">
            <div>
              <strong>${escapeHtml(scan.id)}</strong>
              <div class="scan-target">
                ${escapeHtml(scan.target)}
              </div>
            </div>

            <span class="scan-success">
              ${successful}/${modules.length} OK
            </span>
          </div>

          <div class="scan-date">
            ${escapeHtml(scan.completedAt)}
          </div>

          <div class="scan-modules">
            ${modules.map(module => `
              <span class="${
                module.success
                  ? "module-ok"
                  : "module-error"
              }">
                ${module.success ? "✓" : "×"}
                ${escapeHtml(module.name)}
              </span>
            `).join("")}
          </div>
        </div>
      `;
    }).join("");

  } catch (error) {
    document.getElementById("scans").innerHTML =
      `<div class="empty">Error: ${escapeHtml(error.message)}</div>`;
  }
}

async function loadFindings() {
  try {
    const data = await api("/api/findings");

    const container = document.getElementById("findings");

    if (!data.findings.length) {
      container.innerHTML = "<p>No findings recorded.</p>";
      return;
    }

    container.innerHTML = data.findings.map(finding => `
      <div class="finding">
        <div>
          <strong>${escapeHtml(finding.id)}</strong>
          <span class="severity">
            ${escapeHtml(finding.severity)}
          </span>
        </div>

        <h3>${escapeHtml(finding.title)}</h3>

        <p>
          <strong>Target:</strong>
          ${escapeHtml(finding.target)}
        </p>

        <p>
          <strong>Evidence:</strong><br>
          ${escapeHtml(finding.evidence || "No evidence recorded")}
        </p>

        <p>
          <strong>Description:</strong><br>
          ${escapeHtml(finding.description || "No description")}
        </p>

        <p>
          <strong>Remediation:</strong><br>
          ${escapeHtml(finding.remediation || "No remediation provided")}
        </p>

        <small>
          ${escapeHtml(finding.createdAt)}
        </small>
      </div>
    `).join("");

  } catch (error) {
    document.getElementById("findings").textContent =
      `Error: ${error.message}`;
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeJs(value) {
  return String(value)
    .replaceAll("\\", "\\\\")
    .replaceAll("'", "\\'");
}

window.addEventListener("DOMContentLoaded", async () => {
  await loadOverview();
  await loadTargets();
  await loadFindings();
  await loadScans();
});
